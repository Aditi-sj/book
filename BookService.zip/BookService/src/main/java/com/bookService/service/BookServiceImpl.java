package com.bookService.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.bookService.entity.Book;


import lombok.extern.slf4j.Slf4j;


@Service
@Slf4j
public class BookServiceImpl implements BookService {

	
	
	
	 @Autowired
	    private RestTemplate restTemplate;
	    @Value("${external.header.rapidapi.key}")
	    private String rapidAPi_Key;
	    @Value("${external.header.rapidapi.value}")
	    private String rapidAPi_Key_value;

	    @Value("${external.header.rapid.host.key}")
	    private String rapidAPi_host;
	    @Value("${external.header.rapid.host.value}")
	    private String rapidAPi_host_value;
	    @Value("${external.api}")
	    private String externalAPI;
	    @Override
	    public List<Book> getALlMovies() throws Exception {

	        HttpHeaders headers = new HttpHeaders();
	        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	        headers.set(rapidAPi_Key, rapidAPi_Key_value);
	        headers.set(rapidAPi_host, rapidAPi_host_value);
	        HttpEntity<String> entity = new HttpEntity<String>(headers);
	        long start = System.currentTimeMillis();
	        try{
	            ResponseEntity<List<Book>> resp=restTemplate.exchange(externalAPI, HttpMethod.GET, entity, new ParameterizedTypeReference<List<Book>>() {});
	            log.info(resp.getBody().toString());
	            long end = System.currentTimeMillis();
	            log.info("Time took for fetching "+(end-start));
	            return resp.getBody();
	        }catch (Exception e){
	            throw new Exception(e.getMessage());
	        }
	    }

	    @Override
	    public Book getMovieByRank(long rank) throws Exception {
	        HttpHeaders headers = new HttpHeaders();
	        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	        headers.set(rapidAPi_Key, rapidAPi_Key_value);
	        headers.set(rapidAPi_host, rapidAPi_host_value);
	        headers.set("content-type","application/json");
	        HttpEntity<String> entity = new HttpEntity<String>(headers);
	        long start = System.currentTimeMillis();
	        try{
	            ResponseEntity<Book> resp=restTemplate.exchange(externalAPI+"/top"+rank, HttpMethod.GET, entity,Book.class);
	            log.info(resp.getBody().toString());
	            long end = System.currentTimeMillis();
	            log.info("Time took for fetching "+(end-start));
	            return resp.getBody();
	        }catch (Exception e){
	            throw new Exception(e.getMessage());
	        }
	    }
}
