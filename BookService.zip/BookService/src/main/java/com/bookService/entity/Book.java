package com.bookService.entity;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Book {

	
	private List<String> subcategories;
	
	private boolean english_language_learner;
	
	private List<String> vocab_words;
	
	private List<String> author_first_names;
	
	private int canonical_published_work_id;
	
	private int copyright;
	
	private List<String> subject_tags;
	
	
	private List<String> chapter_measurements;
	
	private List<String> recommended_isbns;
	
	private List<String> author_last_names;
	
	
	private List<String> awards;
	
	private English measurements;
	
	
	private List<PublishedWorkEntity> published_works;
	
	private String title;
	
	private String title_search;
    

    private String series_name;

    private String book_type;

    private String language;

    private List<String> authors;
    
    private List<String> categories;

    private int page_count;
    
    private int max_age;
    
    private int min_age;


    private String summary;
}
