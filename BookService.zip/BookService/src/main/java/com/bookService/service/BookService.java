package com.bookService.service;

import java.util.List;

import com.bookService.entity.Book;


public interface BookService {

	
	 public List<Book> getALlMovies() throws Exception;

	    public Book getMovieByRank(long rank) throws Exception;
}
