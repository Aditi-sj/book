package com.bookService.entity;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class English {

	private double mlf;
	
	private String syntactic_demand_percentile=null;
	
	private String semantic_demand_percentile=null;
	
	private String lexile_code="";
	
	private String decoding_demand_percentile=null;
	
	private boolean measurable;
	
	private double msl;
	
	private int lexile;
	
	private String  structure_demand_percentile=null;
	
	
	 
	
	
	
	
	
}
